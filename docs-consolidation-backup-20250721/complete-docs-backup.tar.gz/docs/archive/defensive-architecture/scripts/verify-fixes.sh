#!/bin/bash

echo "🛡️ DEFENSIVE ARCHITECTURE - FIX VERIFICATION"
echo "==========================================="
echo ""

# Get current directory for relative paths
PROJECT_ROOT="$(pwd)"
REPORTS_DIR="$PROJECT_ROOT/defensive-architecture/reports"

# Check if reports directory exists
if [ ! -d "$REPORTS_DIR" ]; then
  echo "❌ Reports directory not found. Run setup first."
  exit 1
fi

# Get latest violation report
LATEST_REPORT=$(ls -t $REPORTS_DIR/violation-report-*.txt 2>/dev/null | head -1)

if [ -n "$LATEST_REPORT" ]; then
  YESTERDAY_VIOLATIONS=$(grep "violations found" "$LATEST_REPORT" 2>/dev/null | grep -o '[0-9]*' | head -1)
else
  YESTERDAY_VIOLATIONS="374"
fi

# Get current violations
echo "📊 Running current violation check..."
CURRENT_OUTPUT=$(npm run agents:hooks 2>&1)
TODAY_VIOLATIONS=$(echo "$CURRENT_OUTPUT" | grep "violations found" | grep -o '[0-9]*' | head -1)

# Default to 0 if no violations found
if [ -z "$TODAY_VIOLATIONS" ]; then
  TODAY_VIOLATIONS="0"
fi

if [ -z "$YESTERDAY_VIOLATIONS" ]; then
  YESTERDAY_VIOLATIONS="$TODAY_VIOLATIONS"
fi

echo ""
echo "📈 VIOLATION TREND:"
echo "   Previous: $YESTERDAY_VIOLATIONS violations"
echo "   Current: $TODAY_VIOLATIONS violations"

if [ "$TODAY_VIOLATIONS" -lt "$YESTERDAY_VIOLATIONS" ]; then
  FIXED=$((YESTERDAY_VIOLATIONS - TODAY_VIOLATIONS))
  echo "   Fixed: $FIXED violations ✅"
elif [ "$TODAY_VIOLATIONS" -eq "$YESTERDAY_VIOLATIONS" ]; then
  echo "   Status: No change"
else
  NEW_VIOLATIONS=$((TODAY_VIOLATIONS - YESTERDAY_VIOLATIONS))
  echo "   New violations: $NEW_VIOLATIONS ⚠️"
fi

echo ""

# Check performance
echo "⚡ PERFORMANCE CHECK:"
HEALTH_RESPONSE=$(curl -s "http://localhost:1437/api/health" 2>/dev/null)

if [ $? -eq 0 ]; then
  RESPONSE_TIME=$(echo "$HEALTH_RESPONSE" | jq -r '.responseTime' 2>/dev/null | grep -o '[0-9]*')
  STATUS=$(echo "$HEALTH_RESPONSE" | jq -r '.status' 2>/dev/null)
  
  if [ -n "$RESPONSE_TIME" ]; then
    echo "   Response Time: ${RESPONSE_TIME}ms"
    if [ "$RESPONSE_TIME" -lt 50 ]; then
      echo "   Performance: ✅ CHAMPIONSHIP"
    else
      echo "   Performance: ⚠️ DEGRADED"
    fi
  else
    echo "   Response Time: Unable to parse"
  fi
  
  if [ "$STATUS" = "healthy" ]; then
    echo "   Health Status: ✅ HEALTHY"
  else
    echo "   Health Status: ⚠️ $STATUS"
  fi
else
  echo "   Server Status: ❌ NOT RESPONDING"
  echo "   (Server may not be running on port 1437)"
fi

echo ""

# Check build status
echo "🏗️ BUILD CHECK:"
BUILD_OUTPUT=$(npm run build > /tmp/build-check.log 2>&1)
BUILD_EXIT_CODE=$?

if [ $BUILD_EXIT_CODE -eq 0 ]; then
  echo "   Build Status: ✅ SUCCESS"
else
  echo "   Build Status: ❌ FAILED"
  echo "   Check /tmp/build-check.log for details"
fi

echo ""

# Update baseline for next check
echo "$TODAY_VIOLATIONS" > "$REPORTS_DIR/baseline-violations.txt"

# Generate summary
echo "🎯 SUMMARY:"
if [ "$TODAY_VIOLATIONS" -eq 0 ]; then
  echo "   🏆 PERFECT! Zero violations achieved!"
  echo "   🛡️ Defensive Architecture Certification Ready!"
elif [ "$TODAY_VIOLATIONS" -lt 50 ]; then
  echo "   🎯 EXCELLENT! Nearly complete ($TODAY_VIOLATIONS remaining)"
elif [ "$TODAY_VIOLATIONS" -lt 200 ]; then
  echo "   📈 GOOD PROGRESS! ($TODAY_VIOLATIONS remaining)"
else
  echo "   📋 WORK IN PROGRESS ($TODAY_VIOLATIONS remaining)"
fi

echo ""

# Save current report
CURRENT_DATE=$(date +%Y%m%d)
echo "$CURRENT_OUTPUT" > "$REPORTS_DIR/violation-report-$CURRENT_DATE.txt"
echo "📝 Report saved: violation-report-$CURRENT_DATE.txt" 